package com.example.secondscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondScreen extends AppCompatActivity {

    private TextView txtnome, txtemail;
    private Button btn_close;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_screen);

        txtnome = findViewById(R.id.txtNome);
        txtemail = findViewById(R.id.txtEmail);
        btn_close = findViewById(R.id.button2);

        Bundle bundle = getIntent().getExtras();

        Usuario usuario = (Usuario) bundle.getSerializable("usuario");

        String nome = usuario.getNome();
        String email = usuario.getEmail();

        txtnome.setText("Nome: " + nome);
        txtemail.setText("Email: " + email);

        btn_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(SecondScreen.this, MainActivity.class));

            }
        });

    }
}