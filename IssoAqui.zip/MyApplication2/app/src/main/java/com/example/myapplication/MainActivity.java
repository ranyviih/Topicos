package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.myapplication.model.Adapter;
import com.example.myapplication.model.Filme;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Filme> listaFilme = new ArrayList<>();

    public void criarFilme(){
        Filme filme = new Filme("Homen Aranha", "Aventura", "2018");
        this.listaFilme.add(filme);
        filme = new Filme("Senhor dos Aneis", "Aventura", "2015");
        this.listaFilme.add(filme);
        filme = new Filme("A cinco passos de voce", "Drama", "2011");
        this.listaFilme.add(filme);
        filme = new Filme("Minha mae é um piada", "Comedia", "2030");
        this.listaFilme.add(filme);
        filme = new Filme("Ultimato", "Aventura", "2021");
        this.listaFilme.add(filme);
        filme = new Filme("Castelo de Diamante", "Animação", "2012");
        this.listaFilme.add(filme);
        filme = new Filme("Capitao America", "Aventura", "2013");
        this.listaFilme.add(filme);
        filme = new Filme("Frozen", "Animação", "2017");
        this.listaFilme.add(filme);
        filme = new Filme("Batman", "Aventura", "2016");
        this.listaFilme.add(filme);
        filme = new Filme("Barbie", "Animação", "2014");
        this.listaFilme.add(filme);
        filme = new Filme("Enrrolados", "Animação", "2000");
        this.listaFilme.add(filme);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);

        //Listagem de Filme

        this.criarFilme();

        Adapter adapter = new Adapter(listaFilme);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);
    }
}